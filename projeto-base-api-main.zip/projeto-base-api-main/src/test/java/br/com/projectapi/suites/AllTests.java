package br.com.projectapi.suites;

public interface AllTests {
}
