package br.com.projectapi.data.specs;

import io.restassured.RestAssured;
import org.apache.http.HttpStatus;

import static org.hamcrest.Matchers.*;


public class ResponseSpecsUsers {
/*
    public static ResponseSpecsUsers getCadastrarUsers(){
        return new RestAssured().given().when()
                .then()
                .log()
                .all()
                .assertThat().body("name", is(not(emptyOrNullString())))
                .statusCode(HttpStatus.SC_CREATED);
    }

 */
}
